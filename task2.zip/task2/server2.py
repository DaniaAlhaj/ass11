import socket
import os
import re

HOST = '192.168.1.13'
PORT = 5698

def log_request_details(headers, file_path=None):
    print("\n--- User Request Details ---")
    print(f"Method: {headers[0].split()[0]}")
    print(f"Requested Path: {headers[0].split()[1]}")
    for header in headers[1:]:
        print(header.strip())
    if file_path:
        print(f">>> '{file_path}' ")
    print("---------------------------\n")

def log_file_details(file_path):
    try:
        if file_path.endswith('.html') or file_path.endswith('.css'):
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()
            print(f"Serving file: {file_path}")
            
            tags = re.findall(r'(<(h1|h2|h3|ul|ol|li|p|img|a|strong|label|select|button)[^>]*>.*?</\2>|<img[^>]*src="[^"]+"[^>]*>|<a[^>]*href="[^"]+"[^>]*>.*?</a>)', content, re.DOTALL)
            
            for i, tag in enumerate(tags, start=1):
                clean_tag = tag[0].strip()
                print(f"  - Found tag #{i}: {clean_tag}")
        else:
            print(f"Serving binary file: {file_path}")
            
    except Exception as e:
        print(f"Error reading file {file_path}: {e}")
 if method == 'POST':
            content_length = 0
            for header in headers:
                if header.startswith('Content-Length'):
                    content_length = int(header.split()[1])
                    break

            body = request.split('\r\n\r\n')[1]
            if len(body) < content_length:
                body += client_socket.recv(content_length - len(body)).decode()

            params = urllib.parse.parse_qs(body)
            file_type = params.get('file_type', [''])[0]
            file_request = params.get('file_request', [''])[0]

            print(f"File type: {file_type}")
            print(f"File request: {file_request}")

            load_folder = r'\load'
            file_path = os.path.join(load_folder, file_request)


            if os.path.isfile(file_path):
                print("File found!")
                if file_type == 'img':
                    content_type = 'image/jpeg' if file_request.endswith('.jpg') or file_request.endswith('.jpeg') else 'image/png'
                elif file_type == 'video':
                    content_type = (
                        'video/mp4' if file_request.endswith('.mp4') else
                        'video/webm' if file_request.endswith('.webm') else
                        'application/octet-stream'
                    )
                else:
                    content_type = 'application/octet-stream'

                with open(file_path, 'rb') as f:
                    file_data = f.read()

                response = 'HTTP/1.1 200 OK\r\n'
                response += f'Content-Type: {content_type}\r\n'
                response += f'Content-Length: {len(file_data)}\r\n'
                response += 'Accept-Ranges: bytes\r\n\r\n'
                client_socket.sendall(response.encode())
                client_socket.sendall(file_data)
            else:
                
                file_request_encoded = urllib.parse.quote(file_request)
                if file_type == 'img':
                    response = 'HTTP/1.1 307 Temporary Redirect\r\n'
                    response += f'Location: https://www.google.com/search?q={file_request_encoded}&udm=2\r\n'
                    print(response)

                    response += '\r\n'
                    response += '<html><body><h1>Redirecting to image search...</h1></body></html>'
                    client_socket.sendall(response.encode())
                    
                elif file_type == 'video':
                    response = 'HTTP/1.1 307 Temporary Redirect\r\n'
                    response += f'Location: https://www.youtube.com/results?search_query={file_request_encoded}\r\n'
                    print(response)
                    response += '\r\n'
                    response += '<html><body><h1>Redirecting to video search...</h1></body></html>'
                    client_socket.sendall(response.encode())
                else:
                    response = 'HTTP/1.1 415 Unsupported Media Type\r\nContent-Type: text/html\r\n\r\n'
                    response += '<html><body><h1>Unsupported file type</h1></body></html>'
                    client_socket.sendall(response.encode())
     finally:
        client_socket.close()

def serve_file(client_socket, file_path, content_type): 
    try:
        with open(file_path, 'rb') as file:
            content = file.read()
        
        log_file_details(file_path)

        response = f"HTTP/1.1 200 OK\r\nContent-Type: {content_type}\r\nContent-Length: {len(content)}\r\nAccept-Ranges: bytes\r\n\r\n"
        print("Response headers:")
        print(response)
        print(f"Content-Length: {len(content)} bytes")

        response_header = response.encode('utf-8')
        client_socket.sendall(response_header)  
        client_socket.sendall(content)         

        return response_header + content
    except FileNotFoundError:
response = 'HTTP/1.1 405 Method Not Allowed\r\nContent-Type: text/html\r\n\r\n'
response += '<html><body><h1 style="color:red;">The file is not found</h1></body></html>'
client_socket.sendall(response.encode())


        response = "HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\nConnection: close\r\n\r\nFile Not Found"
        print("File not found. Sending 404 response.")
        print(response)
        return response.encode('utf-8')

def handle_request(client_socket):
    request = client_socket.recv(1024).decode('utf-8')
    headers = request.split('\n')
    
    if len(headers) > 0:
        requested_path = headers[0].split()[1]
        log_request_details(headers, requested_path)
        
        if requested_path == '/':
            file_path = 'index.html'
        else:
            file_path = requested_path.lstrip('/')

        content_type = get_content_type(file_path)
        response = serve_file(client_socket, file_path, content_type)  # Pass client_socket here
    else:
        response = "HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain\r\nConnection: close\r\n\r\nBad Request".encode('utf-8')
    
    client_socket.sendall(response)
    client_socket.close()
import socket

def get_ip_address():
    hostname = socket.gethostname()  
    ip_address = socket.gethostbyname(hostname)  
    return ip_address

print("Device IP Address:", get_ip_address())

def get_content_type(file_path):
    ext = os.path.splitext(file_path)[1]
    return {
        '.html': 'text/html',
        '.css': 'text/css',
        '.js': 'application/javascript',
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.mp4': 'video/mp4',
    }.get(ext, 'application/octet-stream')  

def start_server():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind(("", PORT))
        server_socket.listen(5)
        print(f"Server running on http://{HOST}:{PORT}")
        
        while True:
            client_socket, client_address = server_socket.accept()
            print(f"Connection from {client_address}")
            handle_request(client_socket)

if __name__ == '__main__':
    start_server()
